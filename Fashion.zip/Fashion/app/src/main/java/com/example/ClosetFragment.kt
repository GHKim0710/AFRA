package com.example

import androidx.fragment.app.Fragment

class ClosetFragment : Fragment(R.layout.fragment_closet)